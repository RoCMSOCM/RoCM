function VData() {
	// Default constructor
	this.Rkpc = 0;

	this.VROT_GR = 0;
	this.VROT_DARK = 0;
	this.VROT_CONFORMAL = 0;
};

function VData(Rkpc) {
	this.Rkpc = Rkpc;

	this.VROT_GR = 0;
	this.VROT_DARK = 0;
	this.VROT_CONFORMAL = 0;
};

VData.prototype = {};
