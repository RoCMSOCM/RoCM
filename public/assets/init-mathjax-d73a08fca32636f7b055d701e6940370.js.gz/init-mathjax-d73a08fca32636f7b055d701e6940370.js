//MathJax: Latex equations to HTML
window.MathJax = {
	tex2jax: {
		inlineMath: [ ['$','$'], ["\\(","\\)"] ],
		processEscapes: true
	}
};
